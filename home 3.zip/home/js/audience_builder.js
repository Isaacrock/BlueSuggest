// This function takes a search term 'e' as input and sends an AJAX POST request to
// the server to find interest groups related to the search term.
function AdInterest(e) {
  // Prepare the data to be sent in the POST request.
  var r = "searchterm=" + e;

  // Send an AJAX POST request to the '/app/src/audience_builder.php' URL with the data.
  $.ajax({
    type: "POST",
    data: r,
    url: "/app/src/audience_builder.php",
    dataType: "json",
    success: function (e) {
      // If the request is successful, display a success notice.
      Notices("1", "success", "We successfully found interest groups :-)");
    },
    error: function (e) {
      // If there is an error with the request, display an error notice.
      Notices("1", "error", "We tried finding interest groups, but something went wrong :-/");
    }
  });
}
