/**
 * Page Content Loading and Navigation
 *
 * This code uses jQuery to dynamically load content based on the current page's URL path.
 * It detects specific URLs related to cookie policy, privacy policy, and terms of service,
 * and loads the corresponding content into the HTML. Additionally, it adds styling to
 * navigation links to indicate the active page.
 *
 * - If the URL path is "/cookie-policy", it loads the "cookie-policy.php" content.
 * - If the URL path is "/privacy-policy", it loads the "privacy-policy.php" content.
 * - If the URL path is "/terms-of-service", it loads the "terms-of-service.php" content.
 * - It also updates the styling of navigation links to indicate the active page.
 *
 * Note: This code assumes that the HTML structure includes elements with classes
 * "cookie-policy-link," "privacy-policy-link," and "terms-of-service-link" for styling.
 */


$(document).ready((function(){var o=window.location.pathname,i=window.location;"/cookie-policy"==o?$("html").load(i.origin+"/cookie-policy.php"):"/privacy-policy"==o?$("html").load(i.origin+"/privacy-policy.php"):"/terms-of-service"==o?$("html").load(i.origin+"/terms-of-service.php"):"/cookie-policy/"==o?($(".cookie-policy-link").attr("style","border-bottom: 1px solid;"),$(".privacy-policy-link, .terms-of-service-link").attr("style","border-bottom: unset;")):"/privacy-policy/"==o?($(".privacy-policy-link").attr("style","border-bottom: 1px solid;"),$(".cookie-policy-link, .terms-of-service-link").attr("style","border-bottom: unset;")):"/terms-of-service/"==o&&($(".terms-of-service-link").attr("style","border-bottom: 1px solid;"),$(".cookie-policy-link, .privacy-policy-link").attr("style","border-bottom: unset;"))}));