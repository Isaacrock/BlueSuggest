// Execute the following code when the document is ready.
jQuery((function(e) {
    // Add a 'light' class to the site header when the document is scrolled down.
    e(document).scrollTop() > 0 && e(".site-header").addClass("light");

    // Detect scroll events and toggle the 'light' class on the site header.
    e(document).on("scroll", (function() {
        e(document).scrollTop() > 0 ?
            e(".site-header").addClass("light") :
            e(".site-header").removeClass("light");
    }));

    // Add a 'responsive-menu' class to primary and secondary navigation menus.
    // Insert a 'responsive-menu-icon' div before these menus.
    e(".nav-primary .genesis-nav-menu, .nav-secondary .genesis-nav-menu").addClass("responsive-menu")
        .before('<div class="responsive-menu-icon"></div>');

    // Handle click events on the 'responsive-menu-icon'.
    e(".responsive-menu-icon").click((function() {
        // Toggle the visibility of primary and secondary navigation menus.
        e(this).next(".nav-primary .genesis-nav-menu, .nav-secondary .genesis-nav-menu").slideToggle();
    }));

    // Handle window resize events.
    e(window).resize((function() {
        if (window.innerWidth > 800) {
            // Remove inline styles for menus and sub-menus.
            e(".nav-primary .genesis-nav-menu, .nav-secondary .genesis-nav-menu, nav .sub-menu").removeAttr("style");

            // Remove the 'menu-open' class from menu items.
            e(".responsive-menu > .menu-item").removeClass("menu-open");
        }
    }));

    // Handle click events on menu items within the responsive menu.
    e(".responsive-menu > .menu-item").click((function(n) {
        // Toggle the visibility of sub-menus when clicking on a menu item.
        if (n.target === this) {
            e(this).find(".sub-menu:first").slideToggle((function() {
                e(this).parent().toggleClass("menu-open");
            }));
        }
    }));
}));
