// Function to set a cookie with an expiration date
function setCookie(e, t, a) {
    var s = new Date;
    s.setTime(s.getTime() + 24 * a * 60 * 60 * 1e3);
    var r = "expires=" + s.toUTCString();
    document.cookie = e + "=" + t + ";" + r + ";path=/";
}

// Function to get the value of a cookie
function getCookie(e) {
    for (var t = e + "=", a = document.cookie.split(";"), s = 0; s < a.length; s++) {
        for (var r = a[s]; " " == r.charAt(0);) {
            r = r.substring(1);
        }
        if (0 == r.indexOf(t)) {
            return r.substring(t.length, r.length);
        }
    }
    return "";
}

// Function to delete a cookie
function deleteCookie(e) {
    document.cookie = e + "=;expires=Thu, 01 Jan 1970 00:00:01 GMT;";
}

// Function to check if a cookie exists
function checkCookie(e) {
    return "" != getCookie(e);
}

// Function to hide elements on page load based on cookie acceptance
function hideOnLoad() {
    // Check if the COOKIE_ACCEPTED cookie exists and hide specific elements if it does
    checkCookie("COOKIE_ACCEPTED") && $(".cookie-banner").hide();
    $("#update_result").hide();
    $("#lead_form_modal .secondary-set").hide();
    $(".interests_options_parent_div").hide();
}

$(() => {
    // Call the hideOnLoad function to hide elements based on cookie acceptance
    hideOnLoad();

    var clicked_operation = "";
    var selected_results_text = "";
    var selected_results_text_tags = "";
    var selected_results_array = [];
    var selected_results_array_full = [];
    var added_suggestion_array = [];
    var double_quote = '"';
    var location = window.location;
    var current_path_name = window.location.pathname;
    var origin_path = location.origin;
    var current_color = "";

    // Arrays for tag colors
    var sug_tags_color = [
        "#fce9ff", "#efe0ff", "#e1d3ff", "#d5d0ff", "#c4c5ff",
        "#3b5998", "#8b9dc3", "#dfe3ee", "#f7f7f7", "#ffffff"
    ];
    var key_tags_color = [
        "#F55536", "#FA9D6C", "#D0D6B5", "#F4F1BB", "#9BC1BC",
        "#FFC15E", "#FE9B1E", "#F7934C", "#E65A08", "#F96561",
        "#CC5803", "#E2711D", "#FF9505"
    ];
    var sug_tags_color = [
        "#F55536", "#FA9D6C", "#D0D6B5", "#F4F1BB", "#9BC1BC",
        "#FFC15E", "#FE9B1E", "#F7934C", "#E65A08", "#F96561",
        "#CC5803", "#E2711D", "#FF9505"
    ];

    // More code follows...
});
// Function to capitalize the first letter of a string
function ucfirst(e) {
    return e ? (e += "").charAt(0).toUpperCase() + e.substr(1) : "";
}

// Create an object for storing data in local storage
localStorageMap = {
    LS_SEARCH_TERM: ($(".explored_keyword").attr("keyword") + "").split(",").map((e => ucfirst(e))).join(","),
    LS_LANGUAGE: $(".explored_keyword").attr("language") + "",
    LS_SELECTED_RESULTS_ARRAY_FULL: "[]",
    LS_MAX_AUD_SIZE: null,
    LS_MIN_AUD_SIZE: null
};

// Initialize variables
var generate_lead_form = 1;
var generate_lead_form_after_attempts = 0;
var current_language = $(".current_language").attr("current_language");
var is_default_language_set = $(".is_default_language_set").attr("is_default_language_set");

// Check if the "locale_updated" cookie is set, and set it to "0" if not
if (checkLanguageCookie("locale_updated") || setLanguageCookie("locale_updated", "0", "2")) {
    // Language cookie handling
}

// Check if the current page is the "/results" page or the language-specific "/{current_language}/results" page
if ("/results" == current_path_name || current_path_name == "/" + current_language + "/results") {
    // If yes, retrieve data from local storage
    selected_results_array = getLocalStorage("LS_SELECTED_RESULTS_ARRAY") ? JSON.parse(getLocalStorage("LS_SELECTED_RESULTS_ARRAY")) : [];
    selected_results_array_full = getLocalStorage("LS_SELECTED_RESULTS_ARRAY_FULL") ? JSON.parse(getLocalStorage("LS_SELECTED_RESULTS_ARRAY_FULL")) : [];
    min_aud_size = getLocalStorage("LS_MIN_AUD_SIZE");
    max_aud_size = getLocalStorage("LS_MAX_AUD_SIZE");
    var search_term = $(".explored_keyword").attr("keyword");
    added_suggestion_array = [];
    getExploreResults();
    
    // Add a click event listener to language links
    $(".language_link").click((function (e) {
        e.preventDefault();
        var t = $(this).attr("language");
        var a = $(this).attr("code");
        var s = $(this).attr("current_language_code");
        a = a == (s = "" == s || null == s ? a : s) ? a : s;
        setLanguageCookie("current_language", t, "2");
        update_language();
        setLanguageCookie("locale_updated", "1", "2");
        var r = $('<form action="' + (origin_path + "/" + t + "/results") + '" method="post" class="hide_me"><input type="text" name="keyword" value="' + search_term + '" />');
        
        // More code follows...
    }));
}
// Check if the current page is a language-specific page or a generic page
if ("/cookie-policy/" == current_path_name || current_path_name == "/" + current_language + "/cookie-policy/") {
    // If it's the cookie policy page, handle language links for this page
    $(".language_link").click((function (e) {
        e.preventDefault();
        var t = $(this).attr("language");
        //var a = $(this).attr("code"); (not used here)
        
        // Set the current language cookie, update the language, and set the locale_updated cookie
        setLanguageCookie("current_language", t, "2");
        update_language();
        setLanguageCookie("locale_updated", "1", "2");
        
        // Redirect to the selected language's cookie policy page
        redirectTo(origin_path + "/" + t + "/cookie-policy/");
    }));
    
    // Show the footer and delete page data from local storage
    $(".footer").removeClass("hide_me");
    deletePageDataLocalStorage();
} else if ("/privacy-policy/" == current_path_name || current_path_name == "/" + current_language + "/privacy-policy/") {
    // Handle language links for the privacy policy page
    $(".language_link").click((function (e) {
        e.preventDefault();
        var t = $(this).attr("language");
        //var a = $(this).attr("code"); (not used here)
        
        // Set the current language cookie, update the language, and set the locale_updated cookie
        setLanguageCookie("current_language", t, "2");
        update_language();
        setLanguageCookie("locale_updated", "1", "2");
        
        // Redirect to the selected language's privacy policy page
        redirectTo(origin_path + "/" + t + "/privacy-policy/");
    }));
    
    // Show the footer and delete page data from local storage
    $(".footer").removeClass("hide_me");
    deletePageDataLocalStorage();
} else if ("/terms-of-service/" == current_path_name || current_path_name == "/" + current_language + "/terms-of-service/") {
    // Handle language links for the terms of service page
    $(".language_link").click((function (e) {
        e.preventDefault();
        var t = $(this).attr("language");
        //var a = $(this).attr("code"); (not used here)
        
        // Set the current language cookie, update the language, and set the locale_updated cookie
        setLanguageCookie("current_language", t, "2");
        update_language();
        setLanguageCookie("locale_updated", "1", "2");
        
        // Redirect to the selected language's terms of service page
        redirectTo(origin_path + "/" + t + "/terms-of-service/");
    }));
    
    // Show the footer and delete page data from local storage
    $(".footer").removeClass("hide_me");
    deletePageDataLocalStorage();
} else if ("/next-steps/" == current_path_name || current_path_name == "/" + current_language + "/next-steps/") {
    // Handle language links for the next steps page
    $(".language_link").click((function (e) {
        e.preventDefault();
        var t = $(this).attr("language");
        //var a = $(this).attr("code"); (not used here)
        
        // Set the current language cookie, update the language, and set the locale_updated cookie
        setLanguageCookie("current_language", t, "2");
        update_language();
        setLanguageCookie("locale_updated", "1", "2");
        
        // Redirect to the selected language's next steps page
        redirectTo(origin_path + "/" + t + "/next-steps/");
    }));
    
    // Show the footer and delete page data from local storage
    $(".footer").removeClass("hide_me");
    deletePageDataLocalStorage();
} else {
    // Handle language links for other pages
    $(".language_link").click((function (e) {
        e.preventDefault();
        var t = $(this).attr("language");
        //var a = $(this).attr("code"); (not used here)
        
        // Set the current language cookie, update the language, and set the locale_updated cookie
        setLanguageCookie("current_language", t, "2");
        update_language();
        setLanguageCookie("locale_updated", "1", "2");
        
        // Redirect to the selected language's page or home page based on the link
        redirectTo($(this).hasClass("404") ? $(this).attr("href") : origin_path + "/" + t);
    }));
    
    // Show the footer
    $(".footer").removeClass("hide_me");
}// Handle click event on the logo link
$(".logo-link").click((function(e){
    e.preventDefault();
    // Redirect to the home page or language-specific home page
    redirectTo(origin_path + ("1" == is_default_language_set ? "" : "/" + current_language));
})));

// Handle form submission for audience search
$("#audience_search_form").submit((function(e){
    // Prevent form submission if the audience builder search input is empty and show an alert
    if (!$("#audience_builder_search_input").val()) {
        e.preventDefault();
        alert("No value added in Explore Field!!");
    }
})));

// Handle change event on elements with the "selected_result" class
$(document).on("change", ".selected_result", (function(){
    var e = $(this).closest("tbody").attr("class");
    var keyword = $(this).closest("table").attr("keyword");

    if ($("." + e + " .select_all_check_box").prop("checked", !1), this.checked) {
        // If a checkbox is checked, add the selected result to the arrays
        var t = $(this).attr("interests");
        selected_results_array.push(t);
        var a = double_quote + $(this).attr("interests") + double_quote + " , " + double_quote + $(this).attr("audience_size") + double_quote + " , " + double_quote + $(this).attr("path") + double_quote;
        selected_results_array_full.push(a);
    } else {
        // If a checkbox is unchecked, remove the selected result from the arrays
        var s = $(this).attr("interests");
        selected_results_array.splice($.inArray(s, selected_results_array), 1);
        var r = double_quote + $(this).attr("interests") + double_quote + " , " + double_quote + $(this).attr("audience_size") + double_quote + " , " + double_quote + $(this).attr("path") + double_quote;
        selected_results_array_full.splice($.inArray(r, selected_results_array_full), 1);
    }
})));

// Handle click event on elements with the "result_row" class
$(document).on("click", ".result_row", (function(){
    var e = $(this).closest("tbody").attr("class");
    var keyword = $(this).closest("table").attr("keyword");
    $("." + e + " .select_all_check_box").prop("checked", !1);
    var t = $(this).find(".selected_result");
    if (t.prop("checked", !t.prop("checked")), t.prop("checked")) {
        console.log(selected_results_array);
        var a = t.attr("interests");
        selected_results_array.push(a);
        var s = double_quote + t.attr("interests") + double_quote + " , " + double_quote + t.attr("audience_size") + double_quote + " , " + double_quote + t.attr("path") + double_quote;
        selected_results_array_full.push(s);
    } else {
        var r = t.attr("interests");
        selected_results_array.splice($.inArray(r, selected_results_array), 1);
        var o = double_quote + t.attr("interests") + double_quote + " , " + double_quote + t.attr("audience_size") + double_quote + " , " + double_quote + t.attr("path") + double_quote;
        selected_results_array_full.splice($.inArray(o, selected_results_array_full), 1);
    }
}))),
// Handle click events on elements with the "selected_result" class
$(document).on("click", ".selected_result", (function(e){
    // Prevent event propagation
    e.stopPropagation();
    // Return true to allow the event to continue
    return true;
})));

// Handle keyup events on the audience builder search input field
$(document).on("keyup", "#audience_builder_search_input", (function(e){
    // If the input field is empty, reset the added suggestion array and remove added flags
    if (!$(this).val()) {
        added_suggestion_array = [];
        $("#interest_suggestions_parent ul li span").each((function(e){
            $(this).attr("added", "0");
        }));
    }
})));

// Handle click events on elements with the "interest_suggestion_name" class
$(document).on("click", ".interest_suggestion_name", (function(e){
    // Toggle the "added" attribute between "1" and "0"
    var t = "0" === $(this).attr("added") ? "1" : "0";
    var a = $("#audience_builder_search_input").val().split(",");
    
    // Update the "added" attribute, manage the added suggestion array, and show/hide icons
    $(this).attr("added", t);
    if ("1" === t) {
        var s = $(this).attr("name");
        added_suggestion_array.includes(s) || added_suggestion_array.push(s);
        $(".check_icon", this).removeClass("hide_me");
    } else {
        var r = $(this).attr("name");
        added_suggestion_array.splice(added_suggestion_array.indexOf(r), 1);
        a.splice(a.indexOf(r), 1);
        $(".check_icon", this).addClass("hide_me");
        $(".remove_icon", this).addClass("hide_me");
    }
    
    // Generate a comma-separated list of values and update the input field
    var o = added_suggestion_array.filter((e => !a.includes(e)));
    var l = [].concat(a).concat(o).join(",");
    l = l.replace(/^,|,$/g, "");
    $("#audience_builder_search_input").val(l);
    tagsinput_explore.tagsinput("destroy");
    tagsinput_explore.tagsinput("refresh");
})));

// Handle mouseenter and mouseleave events on elements with the "extra-suggestions .sug-tag" class
$(document).on({
    mouseenter: function(){
        if ("1" === $(this).attr("added")) {
            $(".remove_icon", this).removeClass("hide_me");
            $(".check_icon", this).addClass("hide_me");
        }
    },
    mouseleave: function(){
        if ("1" === $(this).attr("added")) {
            $(".check_icon", this).removeClass("hide_me");
            $(".remove_icon", this).addClass("hide_me");
        }
    }
}, ".extra-suggestions .sug-tag");

// Handle mouseenter and mouseleave events on elements with the "apply_all_to_adset" class
$(document).on({
    mouseenter: function(){
        var e = $(this).attr("tag_color");
        $(this).attr("style", "background-color: white; color: " + e + "; border-color: " + e);
    },
    mouseleave: function(){
        var e = $(this).attr("tag_color");
        $(this).attr("style", "background-color: " + e + "; color: white; border-color: " + e);
    }
}, ".apply_all_to_adset"), 
// Handle mouseenter and mouseleave events on elements with the "apply_selected_to_adset" class
$(document).on({
    mouseenter: function(){
        // Change background color, text color, and border color on mouseenter
        var e = $(this).attr("tag_color");
        $(this).attr("style", "background-color: " + e + "; color: white; border-color: " + e);
    },
    mouseleave: function(){
        // Restore styles on mouseleave
        var e = $(this).attr("tag_color");
        $(this).attr("style", "background-color: white; color: #9096a2; border-color: " + e);
    }
}, ".apply_selected_to_adset");

// Handle click events on elements with the "apply_selected_to_adset" class
$(document).on("click", ".apply_selected_to_adset", (function(e){
    e.preventDefault();
    var t = $(this).attr("keyword");

    // Find the current color based on the selected keyword
    $(".explore-section .bootstrap-tagsinput .tag").each((function(){
        if ($(this).text() == t) {
            current_color = $(this).css("background-color");
        }
    }));

    $("#selectedInterests").val("");

    // If there are selected results, process and update the tags
    if (0 !== selected_results_array.length) {
        selected_results_text = "";
        $.each(selected_results_array, (function(e, t){
            selected_results_text += (0 === e ? "" : ",") + t;
            selected_results_text_tags += (0 === e ? "" : ";") + t;
        }));
        $("#selectedInterests").val(selected_results_text);
        tagsinput_selected.tagsinput("destroy");
        refresh_tags(current_color);
        $(".selection .bootstrap-tagsinput input").attr("readonly", "readonly");
        $(".selection .bootstrap-tagsinput input").hide();
        $(".selection .bootstrap-tagsinput").attr("style", "height:auto; min-height:140px; margin-bottom: 20px;");

        // Highlight tags based on the selected results
        $(".selection .bootstrap-tagsinput .tag").each((function(){
            var e = $(this),
                t = $(this).text();
            
            // Find and apply the color from the associated interest result
            $(".interests-results-tbl .selected_result").each((function(){
                if (t == $(this).attr("interests")) {
                    var a = $(this).closest("table").attr("tag_color");
                    e.css({ backgroundColor: a, border: "solid 1px " + a });
                }
            }));
        }));
    } else {
        // If there are no selected results, reset tags and input field
        $("#selectedInterests").val("");
        tagsinput_selected.tagsinput("destroy");
        refresh_tags(current_color);
        $(".selection .bootstrap-tagsinput input").attr("readonly", "readonly");
        $(".selection .bootstrap-tagsinput input").attr("style", "width: 415px;");
        $(".selection .bootstrap-tagsinput").attr("style", "height:auto; min-height:140px; margin-bottom: 20px;");
    }

    // Initialize PerfectScrollbar for the selection-box element
    const a = new PerfectScrollbar(".selection-box", {});
    const s = document.querySelector(".selection-box");
    
    // Reset the scroll position if there are no selected interests
    $("#selectedInterests").val() || (s.scrollTop = 0, a.destroy());

    // Remove selected results data from local storage
    removeLocalStorage("LS_SELECTED_RESULTS_ARRAY");
    removeLocalStorage("LS_SELECTED_RESULTS_ARRAY_FULL");
    setLocalStorage("LS_SELECTED_RESULTS_ARRAY", JSON.stringify(selected_results_array));
})),// Set local storage for selected results array full
setLocalStorage("LS_SELECTED_RESULTS_ARRAY_FULL", JSON.stringify(selected_results_array_full)))
  
// Handle click events on elements with the "apply_all_to_adset" class
$(document).on("click", ".apply_all_to_adset", (function(e){
    e.preventDefault();

    // Iterate through each result row in the interests table
    $("#interests_table .result_row").each((function(e){
        e + 1;
    }));

    // Get the table class attribute
    var t = $(this).attr("table_class");

    // Iterate through checkboxes in the specified table and select them
    $("."+t+" tbody :checkbox").each((function(e){
        $(this).prop("checked", !0);
        var t = $(this).attr("interests");

        // Add the selected results to arrays
        selected_results_array.push(t);
        var a = double_quote + $(this).attr("interests") + double_quote + " , " + double_quote + $(this).attr("audience_size") + double_quote + " , " + double_quote + $(this).attr("path") + double_quote;
        selected_results_array_full.push(a);
    }));

    // Remove duplicate values from selected arrays
    selected_results_array = array_unique(selected_results_array);
    selected_results_array_full = array_unique(selected_results_array_full);

    // Trigger a click event on the "apply_selected_to_adset" element for the specified table
    $("."+t+" .apply_selected_to_adset").trigger("click");
})));

// Handle change events on elements with the "select_all_check_box" class
$(document).on("change", ".select_all_check_box", (function(){
    // Get the table class and selected interests
    var e = $(this).attr("table_class");
    var t = $("#selectedInterests").val();

    if (this.checked) {
        // If the checkbox is checked, trigger a click event on "apply_all_to_adset"
        $("."+e+" .apply_all_to_adset").trigger("click");
        $("#selectedInterests").val(t);

        // Refresh tags and update input field styles
        tagsinput_selected.tagsinput("destroy");
        refresh_tags(current_color);
        $(".selection .bootstrap-tagsinput input").attr("readonly", "readonly");
        if ($("#selectedInterests").val()) {
            $(".selection .bootstrap-tagsinput input").hide();
        } else {
            $(".selection .bootstrap-tagsinput input").attr("style", "width: 320px;");
        }
        $(".selection .bootstrap-tagsinput").css({height: "auto", minHeight: "140px", marginBottom: "20px"});
    } else {
        // If the checkbox is unchecked, iterate through checkboxes and deselect them
        e = $(this).attr("table_class");
        $("."+e+" tbody :checkbox").each((function(e){
            $(this).prop("checked", !1);
            var t = $(this).attr("interests");

            // Remove the deselected results from arrays
            selected_results_array.splice($.inArray(t, selected_results_array), 1);
            var a = double_quote + $(this).attr("interests") + double_quote + " , " + double_quote + $(this).attr("audience_size") + double_quote + " , " + double_quote + $(this).attr("path") + double_quote;
            selected_results_array_full.splice($.inArray(a, selected_results_array_full), 1);
        }));

        // Initialize PerfectScrollbar for the selection-box element
        const a = new PerfectScrollbar(".selection-box", {});
        $("#selectedInterests").val() || a.destroy();
    }
})));

// Handle click events on elements with the "search_btn_results" class
$(".search_btn_results").click((function(e){
    e.preventDefault();
    // Perform an action to get explore results
    getExploreResults();
})), // Handle click event on elements with the "clear_selection" class
$(".clear_selection").click((function(e){
    e.preventDefault();

    // Clear selected interests and related data
    $("#selectedInterests").val("");
    $(".interests-results-tbl tbody :checkbox").each((function(e){
        $(this).prop("checked", !1);
        selected_results_array = [];
        selected_results_array_full = [];
    }));

    // Destroy and refresh tags input, update input field styles
    tagsinput_selected.tagsinput("destroy");
    tagsinput_selected.tagsinput("refresh");
    $(".selection .bootstrap-tagsinput input").attr("readonly", "readonly");
    $(".selection .bootstrap-tagsinput input").attr("style", "width: 350px;");

    // Initialize PerfectScrollbar for the selection-box element
    const t = new PerfectScrollbar(".selection-box", {});
    $("#selectedInterests").val() || t.destroy();

    // Remove selected results data from local storage
    removeLocalStorage("LS_SELECTED_RESULTS_ARRAY");
    removeLocalStorage("LS_SELECTED_RESULTS_ARRAY_FULL");
    setLocalStorage("LS_SELECTED_RESULTS_ARRAY", JSON.stringify(selected_results_array));
    setLocalStorage("LS_SELECTED_RESULTS_ARRAY_FULL", JSON.stringify(selected_results_array_full));
})));

// Initialize the slider and define stop event for #slider-range element
$("#slider-range").slider({
    stop: function(e, t){
        $(".interests_table_parent_div").empty();
        setLocalStorage("LC_MIN_AUD_SIZE", min_aud_size);
        setLocalStorage("LC_MAX_AUD_SIZE", max_aud_size);
        getExploreResults(!0);
    }
}));

// Handle click event on elements with the "copy_to_clipboard" class
$(".copy_to_clipboard").click((function(e){
    if(e.preventDefault(), $("#selectedInterests").val()) {
        if (1 === generate_lead_form) {
            // Logic for lead generation form
            if (clicked_operation = "copy", getCookie("COOKIE_SHOWED_EXPORT")) {
                clicked_operation = "";
                copyToClipboard($("#selectedInterests").val());
                var t = $(".current_language").attr("current_language");
                var a = "1" == is_default_language_set ? "" : "/" + t;
                $.redirect(a + "/next-steps/");
            } else {
                // Show lead generation modal
                $("#lead_form_modal").modal("show");
                $(".lead_form").validate().checkForm();
                $(".get_my_audience").removeClass("disabled").attr("disabled", !1);
            }
        } else {
            // Regular copy to clipboard
            clicked_operation = "";
            copyToClipboard($("#selectedInterests").val());
        }
    } else {
        alert("No value added in adset to Copy!!");
    }
})));

// Handle click event on elements with the "export_to_csv" class
$(".export_to_csv").click((function(e){
    e.preventDefault();
    if ($("#selectedInterests").val()) {
        if (1 === generate_lead_form) {
            // Logic for lead generation form
            clicked_operation = "export";
            if (getCookie("COOKIE_SHOWED_EXPORT")) {
                clicked_operation = "";
                exportToCsv(maintainValueForCsv(selected_results_array_full));
            } else {
                // Show lead generation modal
                $("#lead_form_modal").modal("show");
                $(".lead_form").validate().checkForm();
                $(".get_my_audience").removeClass("disabled").attr("disabled", !1);
            }
        } else {
            // Regular export to CSV
            clicked_operation = "";
            exportToCsv(maintainValueForCsv(selected_results_array_full));
        }
    } else {
        alert("No value added in adset to Export!!");
    }
})));

// Handle click event on elements with the "open_modal" class
$(".open_modal").
// Prevent the default behavior of a click event
(function(e){
    e.preventDefault();
})

// Validate the form with the class "lead_form"
$(".lead_form").validate({
    rules: {
        FNAME: { required: !0, no_test_string: !0 },
        EMAIL: { required: !0, email: !0, no_test_string: !0 },
        COMPANY: { required: !0, no_test_string: !0 },
        WEBSITE: { required: !0, validUrl: !0, no_test_string: !0 },
        DESCRIPTIO: { required: !0, no_test_string: !0 },
        TEAMSIZE: { required: !0, no_test_string: !0 },
        USECASE: { required: !0, no_test_string: !0 }
    },
    submitHandler: function(e) {},
    errorPlacement: function(e, t) {
        return !1;
    }
});

// Add a custom method to validate a valid URL
$.validator.addMethod("validUrl", (function(e, t) {
    var a = $.validator.methods.url.bind(this);
    return a(e, t) || a("http://" + e, t);
}), "Please enter a valid URL");

// Create a blacklist of invalid values
var blacklist = [
    "test", "test@", "test@test", "test@test.", "test@test.com",
    "test@test.co", "test@test.email", "test@test.net", "test@test.in",
    "@test.com", "@test.co", "@test.email", "@test.net", "@test.in",
    "test.", "test.com", "test.co", "test.net", "test.in",
    ".test", "http://test", "http://test.com", "http://test.co",
    "http://test.net", "http://test.in", "https://test", "https://test.com",
    "https://test.co", "https://test.net", "https://test.in"
];

var blacklist_str = "";
var blacklist_length = blacklist.length;

// Function to replace all spaces with "pro"
function replaceAllSpaces(e, t) {
    return "pro";
}

// Function to get explore results
function getExploreResults(e) {
    e || (setLocalStorage("LS_MAX_AUD_SIZE", null), setLocalStorage("LS_MIN_AUD_SIZE", null));
    var t = getLocalStorage("LS_SEARCH_TERM");
    var a = getLocalStorage("LS_LANGUAGE");
    var s = getLocalStorage("LS_MIN_AUD_SIZE");
    var r = getLocalStorage("LS_MAX_AUD_SIZE");

    if ($.fn.dataTable.isDataTable("#interests_table") && $("#interests_table").dataTable().fnDestroy(), !t) {
        return setTimeout((function () {
            $(".loader").addClass("hide_me"),
            $(".display_after_results, .footer").removeClass("hide_me");
        }), 1e3),
        $("#interests_table #interests").empty(),
        void $(".interests_table_parent_div").empty();
    }

    const o = (e, a) => {
        var o = "",
            l = (e = JSON.parse(e)).result,
            n = e.suggestions,
            i = [],
            c = [],
            d = "",
            u = t.split(",");
        if ($("#interests_table #interests").html(""), $(".interests_table_parent_div").empty(), l.data.length > 0)
            if ($(".default_interests_table").hide(), $(".interests_options_parent_div").show(), $("#result_title").html(""), $(".interests_table_parent_div").attr("style", "margin-top:30px;"), $.each(l.data, (function (e, t) {
                $.each(t, (function (e, t) {
                    t = t.data;
                    d = e;
                    var a = t.length,
                        o = u[e],
                        l = "";
                    $(".explore-section .bootstrap-tagsinput .tag").each((function () {
                        $(this).text() == o && (l = $(this).css("backgroundColor"));
                    }));
                    var n = $("<div />").text(o).html();
                    if ($(".interests_table_parent_div").append('\t\t\t\t\t\t\t\t<div style="padding-top:20px;" class="interests_' + e + '">\t\t\t\t\t\t\t\t\t<div class="tablenav top" style="padding-top:0px;">                                  // Apply selected interests to adset and set style attributes
<a href="#" class="button white apply_selected_to_adset trn" table_class="interests_'+e+'" keyword="'+n+'" style="border: 1px solid '+l+' !important; border-width: 1px !important;" tag_color="'+l+'">Apply selected to adset</a>

// Apply all interests to adset and set style attributes
<a href="#" class="button orange apply_all_to_adset trn" table_class="interests_'+e+'" keyword="'+n+'" style="background-color:'+l+'; border: 1px solid '+l+' !important; border-width: 1px !important;" tag_color="'+l+'">Apply all to adset</a>
</div>

<div style="display:flex">
    <!-- Title and count related to interests -->
    <h4 id="result_title" style="font-size: 25px !important;" class="interests_'+e+'_title trn">Explore</h4>
    &nbsp;
    <h4><span class="result_count">'+a+'</span></h4>
    &nbsp;
    <h4 class="trn">interests related to</h4>
    &nbsp;
    <h4>"'+$.trim(n)+'"</h4>
</div>

// Table for displaying interests
<table class="table order-column hover display dataTable no-footer interests_'+e+' interests-results-tbl" id="interests_table" width="100%" role="grid" style="width: 100%;" keyword="'+n+'" tag_color="'+l+'" title_class="interests_'+e+'_title">
    <thead>
        <!-- Table headers -->
        <tr role="row">
            <th id="cb" class="manage-column column-cb check-column sorting_disabled">
                <label class="screen-reader-text trn" for="cb-select-all-1">Select All</label>
                <input id="cb-select-all-1 select_all_check_box" class="select_all_check_box" type="checkbox" table_class="interests_'+e+'">
            </th>
            <th scope="col" class="sorting_disabled trn" rowspan="1" colspan="1">Interests</th>
            <th scope="col" class="sorting_disabled trn" rowspan="1" colspan="1">Audience size</th>
            <th scope="col" class="sorting_disabled trn" rowspan="1" colspan="1">Path</th>
            <th scope="col" class="sorting_disabled search_icons trn" rowspan="1" colspan="1">Search</th>
        </tr>
    </thead>
    <tbody class="interests_'+e+'" id="interests">
    </tbody>
</table>

<div style="padding-top:20px; padding-bottom: 60px;">
<!-- This is a container for the table navigation at the bottom of the page -->
<div class="tablenav bottom">
    <!-- Button to apply selected items to an adset -->
    <a href="#" class="button white apply_selected_to_adset trn" table_class="interests_'+e+'" keyword="'+n+'" style="border: 1px solid '+l+' !important; border-width: 1px !important;" tag_color="'+l+'">Apply selected to adset</a>
    
    <!-- Button to apply all items to an adset -->
    <a href="#" class="button orange apply_all_to_adset trn" table_class="interests_'+e+'" keyword="'+n+'" style="background-color:'+l+"; border: 1px solid "+l+' !important; border-width: 1px !important;" tag_color="'+l+'">Apply all to adset</a>
</div>
</div> <!-- Closing div tag for the parent container -->

<!-- JavaScript code to trigger a click event on the "apply_selected_to_adset" button -->
$(".interests_table_parent_div .apply_selected_to_adset").trigger("click");

// Check if there are items in the 't' array
if (t.length > 0) {
    var _ = 0; // Initialize a counter variable

    // Iterate over items in the 't' array
    $.each(t, (function(e, t) {
        // Check if it's the first item and clear the content if it is
        if (0 == e && $("#interests_table .interests_"+d).html("")) {
            // Conditionally check audience size
            s && r
            if (t.audience_size >= s && t.audience_size <= r) {
                c.push(t); // Add the item to the 'c' array
                ++_; // Increment the counter
                a = t.name.replace(/\,/g,"ˏ"); // Replace commas in the name
                l = $("<div />").text(a).html(); // Escape HTML characters
                o = $.inArray(a, selected_results_array) >= 0 ? "checked" : ""; // Check if the item is selected
                // Append a table row to display the item
                $("#interests_table .interests_"+d).append('<tr class="result_row">\t\t\t\t\t\t\t\t\t\t\t\t\t<td class="check-column trn"><label class="screen-reader-text trn" for="checkbox_e57cdfbc09f4e0f7445c279d9f580bdd">Select</label><input type="checkbox" name="checked[]" value="" id="" arr_key="'+e+'" class="selected_result" interests="'+l+'" audience_size="'+t.audience_size+'" path="'+t.path[0]+" > "+t.path[1]+" > "+t.path[2]+'" '+o+"></td>\t\t\t\t\t\t\t\t\t\t\t\t\t<td>"+l+"</td>\t\t\t\t\t\t\t\t\t\t\t\t\t<td>"+t.audience_size+"</td>');
            }
        } else {
            c.push(t); // Add the item to the 'c' array
            ++_; // Increment the counter
            var a = t.name.replace(/\,/g,"ˏ"); // Replace commas in the name
            var o = $.inArray(a, selected_results_array) >= 0 ? "checked" : ""; // Check if the item is selected
            var l = $("<div />").text(a).html(); // Escape HTML characters
            // Append a table row to display the item
            $("#interests_table .interests_"+d).append('<tr class="result_row">\t\t\t\t\t\t\t\t\t\t\t\t\t<td class="check-column trn"><label class="screen-reader-text trn" for="checkbox_e57cdfbc09f4e0f7445c279d9f580bdd">Select</label><input type="checkbox" name="checked[]" value="" id="" arr_key="'+e+'" class="selected_result" interests="'+l+'" audience_size="'+t.audience_size+'" path="'+t.path[0]+" > "+t.path[1]+" > "+t.path[2]+'" '+o+"></td>\t\t\t\t\t\t\t\t\t\t\t\t\t<td>"+l+"</td>\t\t\t\t\t\t\t\t\t\t\t\t\t<td>"+t.audience_size+"</td>\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td>"+t.path[0]+" > "+t.path[1]+" > "+t.path[2]+'</td>\t\t\t\t\t\t\t\t\t\t\t\t\t\t<td class="search_icons">\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href="https://www.facebook.com/search/pages/?q='+t.name+'" target="_blank" style="margin-right:6px;"><i class="fa fa-facebook-official"></i></a>\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href="https://www.google.com/search?q='+t.name+'" target="_blank"><i class="fa fa-google"></i></a>\t\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\t\t\t\t\t\t\t\t\t\t\t\t\t</tr>')}}else{c.push(t),++_;var a=t.name.replace(/\,/g,"ˏ"),o=$.inArray(a,selected_results_array)>=0?"checked":"",l=$("<div />").text(a).html();$("#interests_table .interests_"+d).append('<tr class="result_row">\t\t\t\t\t\t\t\t\t\t\t\t\t<td class="check-column trn"><label class="screen-reader-text trn" for="checkbox_e57cdfbc09f4e0f7445c279d9f580bdd">Select</label><input type="checkbox" name="checked[]" value="" id="" arr_key="'+e+'" class="selected_result" interests="'+l+'" audience_size="'+t.audience_size+'" path="'+t.path[0]+" > "+t.path[1]+" > "+t.path[2]+'" '+o+"></td>\t\t\t\t\t\t\t\t\t\t\t\t\t<td>"+l+"</td>\t\t\t\t\t\t\t\t\t\t\t\t\t<td>"+t.audience_size+"</td>\t\t\t\t\t\t\t\t\t\t\t\t\t<td>"+t.path[0]+" > "+t.path[1]+" > "+t.path[2]+'</td>\t\t\t\t\t\t\t\t\t\t\t\t\t<td class="search_icons">\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href="https://www.facebook.com/search/pages/?q='+t.name+'" target="_blank" style="margin-right:6px;"><i class="fa fa-facebook-official"></i></a>\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href="https://www.google.com/search?q='+t.name+'" target="_blank"><i class="fa fa-google"></i></a>\t\t\t\t\t\t\t\t\t\t\t\t\t</td>\t\t\t\t\t\t\t\t\t\t\t\t</tr>')}i.push(t.audience_size)})),$(".interests_table_parent_div .interests_"+e+" .result_count").text(_)}}))})),$("#update_result").show(),a(i),setResponceAsDatable(),n.data.length>0){$("#interest_suggestions_parent ul").html("");var _="cursor: pointer;color:white;";$.each(n.data,(function(e,t){color_management(e,10);var a=_+"background-color:white;border-color:#5d5d5d; color: black;";$("#interest_suggestions_parent ul").append('<li><span class="sug-tag default-sug-tag trn interest_suggestion_name" name="'+t.name+'" style='+a+' added="0">'+t.name+'<div class="check-icons"><i class="fa fa-check check_icon hide_me" aria-hidden="true"></i><i class="fa fa-times remove_icon hide_me" aria-hidden="true"></i></div></span></li>')}))}else{_='style="cursor: pointer;"';$("#interest_suggestions_parent ul").html('<li><span class="sug-tag default-sug-tag trn" id="not-found" name="not-found" '+_+">No suggestions found.</span></li>")}else{$("#update_result").hide(),$("#result_title").html("Please use above interests explore bar to get your interests results."),o=""!==t?'No results found for "'+t+'"':"No results found";var p=$('<td colspan="5" class="trn"></td>').text(o),g=$("<tr></tr>");g.append(p),$("#interests_table #interests").append(g)}s&&r||0===c.length&&$("#result_title").html("No results found in selected audience range."),document.getElementById("interest_suggestions_parent").click(),$(".check-column").removeClass("sorting_asc"),$(".interests-results-tbl").each((function(){$(this);var e=$(this).attr("title_class");$("tr",this).each((function(t){$("."+e+" .result_count").text(t),"5"==$("td",this).attr("colspan")&&$("."+e+" .result_count").text("0")}))})),$(".loader").addClass("hide_me"),$(".display_after_results, .footer").removeClass("hide_me")};e&&this._cache_data?o(this._cache_data,(()=>{})):($.ajax({url:"/functions/fb_functions.php",type:"POST",data:{search_term:t,language:a},beforeSend:function(){$(".loader").removeClass("hide_me")},success:e=>{this._cache_data=e,o(e,(e=>{var t,a,o=Math.max.apply(Math,e),l=Math.min.apply(Math,e);s>=l&&r<=o?(t=s,a=r):(t=l,a=o),s&&r||(t=l,a=o),$("#audience_size").val(t+" - "+a),setLocalStorage("LS_MIN_AUD_SIZE",t),setLocalStorage("LS_MAX_AUD_SIZE",a),$("#slider-range").slider({range:!0,min:l,max:o,values:[t,a],slide:function(e,t){setLocalStorage("LS_MIN_AUD_SIZE",t.values[0]),setLocalStorage("LS_MAX_AUD_SIZE",t.values[1]),$("#audience_size").val(t.values[0]+" - "+t.values[1])}})}))}}),$(".selection .bootstrap-tagsinput input").attr("style","width: 340px;"),$(".explore-section .bootstrap-tagsinput input").attr("style","width: 420px;"))}function copyToClipboard1(){$(".loader").removeClass("hide_me"),document.getElementById("selectedInterests").select(),document.execCommand("copy"),setTimeout((function(){$(".loader").addClass("hide_me")}),200)}function copyToClipboard(e){$(".loader").removeClass("hide_me");var t=document.createElement("input");t.style="position: absolute; left: -1000px; top: -1000px",t.value=e,document.body.appendChild(t),t.select(),document.execCommand("copy"),document.body.removeChild(t),setTimeout((function(){$(".loader").addClass("hide_me")}),200)}function redirectTo(e){window.location=e}function exportToCsv(value=""){var a=document.createElement("a");with(a)href="data:text/csv;base64,"+btoa(unescape(encodeURIComponent(value))),download="interests.csv";document.body.appendChild(a),a.click(),document.body.removeChild(a)}function setResponceAsDatable(e=1){1==e?$(".interests-results-tbl").dataTable({destroy:!0,columnDefs:[{orderable:!1,targets:0},{orderable:!1,targets:4}],paging:!1,info:!1,searching:!1}):$("#interests_table").dataTable()}function array_unique(e){return $.grep(e,(function(t,a){return a===$.inArray(t,e)}))}function autosize(){var e=this;setTimeout((function(){e.style.cssText="height:auto; padding:0",e.style.cssText="height:"+e.scrollHeight+"px"}),0)}function textAreaAutoSize(e){var t=$("."+e)[0].scrollHeight;setTimeout((function(){$("."+e).attr("style","height:auto; padding:0"),$("."+e).attr("style","height:"+t+"px")}),0)}function showChip(e){$("."+e+" .chip").removeAttr("style")}function showTrueIcon(e){$("."+e+" .true_icon").removeAttr("style")}function hideChip(e){$("."+e+" .chip").attr("style","display : none !important;")}function hideTrueIcon(e){$("."+e+" .true_icon").attr("style","display : none !important;")}function addUserInfo(e,t,a,s,r,o,l,n,i,c,d=""){$.ajax({url:"/functions/user_functions.php",type:"POST",data:{operation:"add",full_name:e,work_email_address:t,company_name:a,website:s,description:r,teamsize:o,usecase:l,status:n,explored_key:i},beforeSend:function(){$(".loader").removeClass("hide_me")},success:function(e){if("true"==e){$(".loader").addClass("hide_me"),$("#lead_form_modal").modal("hide");if("copy"==c)copyToClipboard($("#selectedInterests").val())," & results are copied to clipboard!!";else if("export"==c){exportToCsv(maintainValueForCsv(d)),deselectAll()," & results are exported to CSV!!"}setCookie("COOKIE_SHOWED_EXPORT",1,60);$(".explored_keyword").attr("language");var t=$(".current_language").attr("current_language"),a="1"==is_default_language_set?"":"/"+t,s=$("#mce-FNAME").val(),r=$("#mce-EMAIL").val(),o=$("#mce-COMPANY").val(),l=$("#mce-WEBSITE").val(),n=$("#mce-DESCRIPTION").val(),i=$("#mce-TEAMSIZE").val(),u=$("#mce-USECASE").val();setCookie("_FNAME",s,365),setCookie("_EMAIL",r,365),setCookie("_COMPANY",o,365),setCookie("_WEBSITE",l,365),setCookie("_DESCRIPTION",n,365),setCookie("_TEAMSIZE",i,365),setCookie("_USECASE",u,365),$.redirect(a+"/next-steps/")}}})}function deselectAll(){var e=document.activeElement;e&&/INPUT|TEXTAREA/i.test(e.tagName)&&("selectionStart"in e&&(e.selectionEnd=e.selectionStart),e.blur()),window.getSelection?window.getSelection().removeAllRanges():document.selection&&document.selection.empty()}function setLocalStorage(e,t){return localStorageMap[e]=t,localStorageMap}function getLocalStorage(e){return localStorageMap[e]}function removeLocalStorage(e){delete localStorageMap[e]}function deletePageDataLocalStorage(){removeLocalStorage("LS_SEARCH_TERM"),removeLocalStorage("LS_LANGUAGE"),removeLocalStorage("LS_MIN_AUD_SIZE"),removeLocalStorage("LS_MAX_AUD_SIZE"),removeLocalStorage("LS_SELECTED_RESULTS_ARRAY"),removeLocalStorage("LS_SELECTED_RESULTS_ARRAY_FULL")}function maintainValueForCsv(e){var t="",a=e;return 0!==a.length&&($.each(a,(function(e,a){t+="\n"+a})),t="Interests, Audience Size, Path"+t),t}function clearLeadFormFields(){$(this).find("input,textarea,select").val("").end().find("input[type=checkbox], input[type=radio]").prop("checked","").end()}function color_management(e,t){if(parseInt(e)>=parseInt(t)){if(parseInt(e)>99){var a=e.toString().substr(2);return parseInt(a)}a=e.toString().substr(1);return parseInt(a)}return parseInt(e)}if($.each(blacklist,(function(e,t){blacklist_str+=(0===e?"(":"")+t+(e===blacklist_length-1?")":"|")})),jQuery.validator.addMethod("no_test_string",(function(e){return!0!==new RegExp("\\b"+blacklist_str+"\\b","i").test(e)}),'Please enter a valid word, "test" words are not accepted'),jQuery.validator.addMethod("no_test_in_string",(function(e){return e.indexOf("test")<0}),'Please enter a valid word, "test" words are not accepted'),$(document).on("keyup click",".full_name, .work_email_address, .company_name, .website, .description, .teamsize, .usecase",(function(){if($(".lead_form").valid())$(".get_my_audience").removeClass("disabled"),$(".get_my_audience").removeAttr("disabled"),$(".description").hasClass("valid")&&$(".teamsize").hasClass("valid")&&$(".usecase").hasClass("valid");else{$(".get_my_audience").attr("name");$(".get_my_audience").hasClass("disabled")}$(".full_name").valid()&&$(".work_email_address").valid()&&$(".company_name").valid()&&$(".website").valid()?($("#lead_form_modal .secondary-set").show(),$("#lead_form_modal .secondary-set").attr("check_validate","1")):($("#lead_form_modal .secondary-set").hide(),"1"===$("#lead_form_modal .secondary-set").attr("check_validate")||($(".description").attr("style","border: unset !important;"),$(".teamsize").attr("style","border: unset !important;"),$(".usecase").attr("style","border: unset !important;"))),$(".lead_form").validate().checkForm(),$(".get_my_audience").removeClass("disabled").attr("disabled",!1)})),$(document).on("click keyup",".full_name",(function(){var e="full_name_group";$(".full_name").valid()?(hideChip(e),showTrueIcon(e)):(showChip(e),hideTrueIcon(e))})),$(document).on("click keyup",".work_email_address",(function(){var e="work_email_address_group";$(".work_email_address").valid()?(hideChip(e),showTrueIcon(e)):(showChip(e),hideTrueIcon(e))})),$(document).on("click keyup",".company_name",(function(){var e="company_name_group";$(".company_name").valid()?(hideChip(e),showTrueIcon(e)):(showChip(e),hideTrueIcon(e))})),$(document).on("click keyup",".website",(function(){var e="website_group";$(".website").valid()?(hideChip(e),showTrueIcon(e)):(showChip(e),hideTrueIcon(e))})),$(document).on("click keyup change",".description, .teamsize, .usecase",(function(){var e=$(this).valid()?"border: 1px solid #a0cc83; !important":"border: 1px solid #fa5738; !important";$(this).attr("style",e)})),$(".full_name").focusout((function(){})),$(".work_email_address").focusout((function(){})),$(".company_name").focusout((function(){})),$(".website").focusout((function(){})),$(".get_my_audience").on("click",(function(){if($(".lead_form").valid()){var e=$(".full_name").val(),t=$(".work_email_address").val(),a=$(".company_name").val(),s=$(".website").val(),r=$(".description").val(),o=$(".teamsize").val(),l=$(".usecase").val(),n=$("#audience_builder_search_input").attr("parent_explored_value"),i="border: 1px solid #a0cc83; !important",c="border: 1px solid #fa5738; !important";$(".description").hasClass("valid")?$(".description").attr("style",i):$(".description").attr("style",c),$(".teamsize").hasClass("valid")?$(".teamsize").attr("style",i):$(".teamsize").attr("style",c),$(".usecase").hasClass("valid")?$(".usecase").attr("style",i):$(".usecase").attr("style",c),addUserInfo(e,t,a,s,r,o,l,"lead",n,clicked_operation,selected_results_array_full),copyToClipboard($("#selectedInterests").val())}else{i="border: 1px solid #a0cc83; !important",c="border: 1px solid #fa5738; !important";$(".description").hasClass("valid")?$(".description").attr("style",i):$(".description").attr("style",c),$(".teamsize").hasClass("valid")?$(".teamsize").attr("style",i):$(".teamsize").attr("style",c),$(".usecase").hasClass("valid")?$(".usecase").attr("style",i):$(".usecase").attr("style",c)}var d="full_name_group",u="work_email_address_group",_="company_name_group",p="website_group";$(".full_name").valid()?(hideChip(d),showTrueIcon(d)):(showChip(d),hideTrueIcon(d)),$(".work_email_address").valid()?(hideChip(u),showTrueIcon(u)):(showChip(u),hideTrueIcon(u)),$(".company_name").valid()?(hideChip(_),showTrueIcon(_)):(showChip(_),hideTrueIcon(_)),$(".website").valid()?(hideChip(p),showTrueIcon(p)):(showChip(p),hideTrueIcon(p))})),$("#lead_form_modal").on("hidden.bs.modal",(function(e){$(this).find("input,textarea,select").val("").end().find("input[type=checkbox], input[type=radio]").prop("checked","").end(),$(".true_icon",this).hide(),$(".secondary-set",this).hide(),$(".chip").attr("style","display: none !important;"),$(".description, .teamsize, .usecase").attr("style","border: unset;"),$("#lead_form_modal .secondary-set").removeAttr("check_validate")})),"/results"==current_path_name||current_path_name=="/"+current_language+"/results"){var tagsinput_explore=$("#audience_builder_search_input"),tagsinput_selected=$("#selectedInterests");function addTags(){refresh_tags(current_color)}function refresh_tags(e){tagsinput_selected.tagsinput("destroy"),tagsinput_selected.tagsinput("refresh"),tagsinput_explore.tagsinput("destroy"),tagsinput_explore.tagsinput("refresh"),$(".explore-section .bootstrap-tagsinput .tag").each((function(e){var t=color_management(e,10);$(this).css({backgroundColor:key_tags_color[t],borderColor:key_tags_color[t]})})),$(".selection .bootstrap-tagsinput .tag").each((function(e){var t=$(this),a=$(this).text();$(".interests-results-tbl .selected_result").each((function(){if(a==$(this).attr("interests")){var e=$(this).closest("table").attr("tag_color");t.css({backgroundColor:e,border:"1px solid "+e})}}))}))}function unique(e){return $.grep(e,(function(t,a){return a===$.inArray(t,e)}))}tagsinput_explore.val(getLocalStorage("LS_SEARCH_TERM")),tagsinput_explore.attr("data-role","tagsinput temptext"),tagsinput_selected.attr("data-role","tagsinput temptext"),$(document).on("click",".sug-tag",(function(){addTags()})),refresh_tags(current_color),$(".selection .bootstrap-tagsinput input").attr("readonly","readonly"),$(".selection .bootstrap-tagsinput input").attr("style","width:350px;"),$(".selection .bootstrap-tagsinput").attr("style","height:auto; min-height:140px; margin-bottom: 20px;"),tagsinput_explore.on("itemAddedOnInit",(function(e){e.item=ucfirst(e.item)})),tagsinput_explore.on("beforeItemAdd",(function(e){var t=ucfirst(e.item);e.item!==t&&(e.cancel=!0,tagsinput_explore.tagsinput("add",t))})),tagsinput_explore.on("itemAdded",(function(e){var t=$("#audience_builder_search_input").val();if(getLocalStorage("LS_SEARCH_TERM")!==t){$(".explore-section .bootstrap-tagsinput .tag").each((function(e){var t=color_management(e,10);$(this).css({backgroundColor:key_tags_color[t],borderColor:key_tags_color[t]})}));var a=array_unique(t.split(",")),s="";if(a.length)s=a[a.length-1];setLocalStorage("LS_SEARCH_TERM",a.join(",")),s==e.item&&(getExploreResults(),fbq("init","1210815975741636"),fbq("track","PageView"),fbq("track","Search",{search_string:a}),$(".keyword_noscript_tag").html('<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=1210815975741636&ev=Search&cd[search_string]='+encodeURIComponent(a)+'&noscript=1" /></noscript>'))}})),tagsinput_explore.on("beforeItemRemove",(function(e){var t=e.item,a=unique(added_suggestion_array);a.splice($.inArray(t,a),1),added_suggestion_array=a,$("#interest_suggestions_parent li span").each((function(){$(this).attr("name")==t&&($(this).attr("added","0"),$(".check_icon",this).addClass("hide_me"),$(".remove_icon",this).addClass("hide_me"))}))})),tagsinput_explore.on("itemRemoved",(function(){setLocalStorage("LS_SEARCH_TERM",$("#audience_builder_search_input").val().split(",").join(","))})),tagsinput_selected.on("itemAdded",(function(e){})),tagsinput_selected.on("beforeItemRemove",(function(e){var t=e.item,a="";$(".interests-results-tbl .selected_result").each((function(){t==$(this).attr("interests")&&(a=double_quote+$(this).attr("interests")+double_quote+" , "+double_quote+$(this).attr("audience_size")+double_quote+" , "+double_quote+$(this).attr("path")+double_quote,$(this).prop("checked",!1))})),$.inArray(t,selected_results_array)>=0&&selected_results_array.splice($.inArray(t,selected_results_array),1),$.inArray(a,selected_results_array_full)>=0&&selected_results_array_full.splice($.inArray(a,selected_results_array_full),1),0===selected_results_array.length&&$(".clear_selection").trigger("click"),removeLocalStorage("LS_SELECTED_RESULTS_ARRAY"),removeLocalStorage("LS_SELECTED_RESULTS_ARRAY_FULL"),setLocalStorage("LS_SELECTED_RESULTS_ARRAY",JSON.stringify(selected_results_array)),setLocalStorage("LS_SELECTED_RESULTS_ARRAY_FULL",JSON.stringify(selected_results_array_full))})),$(".explore-section .bootstrap-tagsinput input").attr("style","width: 420px;")}$(document).on("click",".cookie_got_it",(function(e){e.preventDefault(),$(".cookie-banner").hide(),setCookie("COOKIE_ACCEPTED",1,"365")})),checkCookie("COOKIE_ACCEPTED")||($(".cookie-banner").html('<div class="cookie-wrap">            <p class="trn">The website uses cookies to ensure you get the best experience on our website</p>            <p><a href="/cookie-policy/" class="trn">Learn More</a></p>            <a class="btn cookie_got_it trn" href="#">Got It</a>        </div>'),update_language()),$(window).scroll((function(){$(window).scrollTop()>187?$(".policy-links").addClass("fixed"):$(".policy-links").removeClass("fixed")})),$(".toggle-links").click((function(){$("ul.policy-links").toggleClass("show_me")})),$(".navbar-toggle").click((function(){$("#navbar").hasClass("show_me")})),checkLanguageCookie("current_language")||setLanguageCookie("current_language","en","2"),$(document).ajaxComplete((function(){update_language()}))}))})(jQuery);