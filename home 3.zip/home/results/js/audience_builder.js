/**
 * AdInterest Function
 *
 * This function is responsible for making an AJAX request to "/app/src/audience_builder.php"
 * to find interest groups based on a given search term.
 *
 * @param {string} e - The search term for finding interest groups.
 */
function AdInterest(e) {
    // Create a data string to send in the AJAX request.
    var r = "searchterm=" + e;

    // Make an AJAX POST request to the specified URL.
    $.ajax({
        type: "POST",
        data: r,
        url: "/app/src/audience_builder.php",
        dataType: "json",
        success: function (response) {
            // If the request is successful, display a success notice.
            Notices("1", "success", "We successfully found interest groups :-)");
        },
        error: function (error) {
            // If there's an error, display an error notice.
            Notices("1", "error", "We tried finding interest groups, but something went wrong :-/");
        }
    });
}
